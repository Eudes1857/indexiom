export const DiscoverDataLeft = {
  heading:
    "Découvrez<br/> notre audit gratuit: <br/>ou jouer et comment <br/>gagner plus de profils",
};

export const DiscoverDataRight = {
  heading: "Audit marketing 360° gratuit",
  items: [
    {
      label: "30 jours d'audit gratuit",
    },
    {
      label: "Abonnement mensuel sans engagement",
    },
  ],
};
