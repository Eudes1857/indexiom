export const MenuData = [
  {
    title: "Notre méthode",
    link: "/notre-methode",
  },
  {
    title: "Le catalogue",
    link: "/catalogue-indexiom",
  },
  {
    title: "Notre équipe",
    link: "/notre-equipe",
  },
  {
    title: "La fondation",
    link: "/fondation",
  },
  {
    title: "Se connecter",
    link: "/se-connecter",
  },
  {
    title: "Demarrer mon projet",
    link: "/demarrer",
  },
  {
    title: "Nous contacter",
    link: "/nous-contacter",
  },
];
